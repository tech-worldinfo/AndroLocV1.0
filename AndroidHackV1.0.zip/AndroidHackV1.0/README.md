===============================================================
-----------------------
TECH-WORLDINFO
----------------------
website: https://h43k0r.data.blog
Telegram: https://t.me/@H43K0R
Telegram group: https://t.me/+rsXxTfABomtjZWEo
Email: tech-worldinfo@protonmail.com
Contact: 🤣🤣🤣🤣🤣
=====================================================================================
⚠⚠ This tool is intended for legal testing purposes, mis-use of the tool ain't responsible
for the illegal actions under any circumstances

______________
USAGE
---------------
==> You need an API key from the https://ipinfo.io
=> Save the API key in the token.txt file in the root dir.
=> the rest is automatic.
==> you need to use any tunneling software/tool [ngrok, ssh tunnel...]
=================================================================================
------------------------------
[HINT USAGE OPTIONS]
------------------------------

=> embed this file 'index.php' in any webpage as a link
=> modify the 'index.php' file to attract the victim attention



================================================================================
__________________
EXPERT USAGE
------------------
+>you need some social engineering techniques to use this tool.

*EXAMPLE*
**> you need to be good in website cloning
**> Know the Target preferences.
**> Ability to embed this script in html or any webpage/site
**> able to host the website locally or any other method


WARNING:
    => GEO LOCALTION DATA IS INACCURATE, lol, IK THAT IF YOU HAVE YOUR ACCURATE API  OR ANY WAY CONTACT ME ASAP