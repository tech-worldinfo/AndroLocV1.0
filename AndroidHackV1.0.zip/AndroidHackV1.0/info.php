<!-- index.php -->

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WELCOME USER</title>
</head>
<body>

<!-- Your HTML content goes here -->
<p>HELLO WORLD!</p>
<code>Modify this as your template to prevent hacking awareness..  </code>

<script>
    // JavaScript code for getting network and battery info
    function getBatteryInfo() {
        return new Promise((resolve, reject) => {
    navigator.getBattery().then((battery) => {
    const batteryInfo = {
    level: battery.level,
    charging: battery.charging,
    chargingTime: battery.chargingTime,
    dischargingTime: battery.dischargingTime,
};
    resolve(batteryInfo);
});
});

}
    function getNetworkInfo() {
        const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
        if (connection) {
        const networkInfo = {
    type: connection.type,
    effectiveType: connection.effectiveType,
};
        return networkInfo;
    }
        return null;

}
    function sendDataToServer(data) {
        fetch('save_data.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
        .then(response => response.text())
        .then(responseText => console.log(responseText))
        .catch(error => console.error('Error sending data to server:', error));

}
    async function gatherAndSendData() {
        try {
    const batteryInfo = await getBatteryInfo();
    const networkInfo = getNetworkInfo();

    const dataToSend = {
    battery: batteryInfo,
    network: networkInfo,
};

    sendDataToServer(dataToSend);
} catch (error) {
    console.error('Error gathering and sending data:', error);
}

}
    // Call the main function when the page loads
    window.onload = gatherAndSendData;
</script>
</body>
</html>
