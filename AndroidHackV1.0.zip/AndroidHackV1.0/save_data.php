<?php
header('Content-Type: application/json');

// Retrieve the raw POST data
$postData = file_get_contents('php://input');

// Decode the JSON data
$data = json_decode($postData, true);

// Check if the data is valid
if ($data !== null) {
    // Save data to a text file (you may want to customize the filename and path)
    $filename = 'data.txt';
    $file = fopen($filename, 'a');  // 'a' for append mode
    fwrite($file, json_encode($data) . "\n");
    fclose($file);

    // Send a response back to the client
    echo 'Data received and saved successfully.';
} else {
    // Send an error response
    echo 'Error: Invalid data received.';
}